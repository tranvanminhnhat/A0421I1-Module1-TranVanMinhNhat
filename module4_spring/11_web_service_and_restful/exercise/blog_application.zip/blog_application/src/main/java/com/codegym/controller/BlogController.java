package com.codegym.controller;

import com.codegym.model.Blog;
import com.codegym.model.BlogForm;
import com.codegym.model.Category;
import com.codegym.service.IBlogService;
import com.codegym.service.ICategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;

@RestController
@RequestMapping("/api/blog")
public class BlogController {
    @Autowired
    private IBlogService blogService;

    @Autowired
    private ICategoryService categoryService;
//
//    @PostMapping("/sort")
//    public ModelAndView showListDesc(Pageable pageable){
//        Page<Blog> blogs = blogService.findAllDesc(pageable);
//        ModelAndView modelAndView = new ModelAndView("blog/list");
//        modelAndView.addObject("blogs", blogs);
//        return modelAndView;
//    }

//    @PostMapping("search")
//    public ModelAndView showSearchedList(@RequestParam String title, Pageable pageable){
//        Page<Blog> blogs = blogService.findAllByTitle(title, pageable);
//        ModelAndView modelAndView = new ModelAndView("blog/list");
//        modelAndView.addObject("blogs", blogs);
//        return modelAndView;
//    }

//    @GetMapping("/create")
//    public ModelAndView showCreateForm(){
//        ModelAndView modelAndView = new ModelAndView("blog/create");
//        modelAndView.addObject("blog",new Blog());
//        modelAndView.addObject("categories", categoryService.findAll());
//        return modelAndView;
//    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.OK)
    public String createBlog(@RequestBody BlogForm blogForm){
        Blog blog = new Blog(blogForm.getBlogId(), blogForm.getTitle(), blogForm.getContent(), blogForm.getAuthor(), blogForm.getDate());
        blog.setCategory(categoryService.findById(blogForm.getCategoryId()).orElse(null));
        blogService.save(blog);
        return "Success";
    }

    @GetMapping("/list")
    @ResponseStatus(HttpStatus.OK)
    public Iterable<Blog> showList(){
        return blogService.findAll();
    }

    @PutMapping("/edit")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Blog> updateBlog(@RequestBody BlogForm blogForm){
//        Optional<Blog> blogGot = blogService.findById(id);
//        if (!blogGot.isPresent()){
//            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//        }
//        Blog blog = new Blog(blogForm.getBlogId(), blogForm.getTitle(), blogForm.getContent(), blogForm.getAuthor(), blogForm.getDate());
//        blog.setCategory(categoryService.findById(blogForm.getCategoryId()).orElse(null));
//        blog.setBlogId(blogGot.get().getBlogId());
        Category category = categoryService.findById(blogForm.getCategoryId()).orElse(null);
        Blog blog = new Blog(blogForm.getBlogId(), blogForm.getTitle(), blogForm.getContent(), blogForm.getAuthor(), blogForm.getDate(),category);
        return new ResponseEntity<>(blogService.save(blog), HttpStatus.OK);
    }


//    @DeleteMapping("/delete")
//    public ModelAndView deleteBlog(@ModelAttribute("blog") Blog blog){
//        blogService.remove(blog.getBlogId());
//        ModelAndView modelAndView = new ModelAndView("blog/delete");
//        modelAndView.addObject("blog", blog);
//        modelAndView.addObject("message", "Delete blog successfully");
//        return modelAndView;
//    }
}
